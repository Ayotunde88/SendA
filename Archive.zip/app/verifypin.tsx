import VerifyPinScreen from "../components/src/screens/VerifyPinScreen";
export default VerifyPinScreen;
