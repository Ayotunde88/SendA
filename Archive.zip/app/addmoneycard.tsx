import AddMoneyCardScreen from "../components/src/screens/AddMoney/AddMoneyCardScreen";
export default AddMoneyCardScreen;