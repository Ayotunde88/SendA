import PlaceholderScreen from "../components/src/screens/PlaceholderScreen";
export default function Screen() {
  return <PlaceholderScreen title="Help" />;
}
