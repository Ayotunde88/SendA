import PinScreen from "../components/src/screens/PinScreen";
export default PinScreen;
