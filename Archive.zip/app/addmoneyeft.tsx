import AddMoneyEFTScreen from "../components/src/screens/AddMoney/AddMoneyEFTScreen";
export default AddMoneyEFTScreen;