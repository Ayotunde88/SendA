import WithdrawScreen from "../components/src/screens/WithdrawScreen";

export default WithdrawScreen;