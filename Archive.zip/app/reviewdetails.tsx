import ReviewDetailsScreen from "../components/src/screens/ReviewDetailsScreen";
export default ReviewDetailsScreen;
