import RateAlertsScreen from "../components/src/screens/RateAlertsScreen";
export default RateAlertsScreen;