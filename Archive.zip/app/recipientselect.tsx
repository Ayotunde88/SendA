import RecipientSelectScreen from "../components/src/screens/RecipientSelectScreen";
export default RecipientSelectScreen;