import SecurityPrivacyScreen from "../components/src/screens/SecurityPrivacyScreen";
export default SecurityPrivacyScreen;
