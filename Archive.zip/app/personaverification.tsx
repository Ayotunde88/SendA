import PersonaVerificationScreen from "../components/src/screens/PersonaVerificationScreen";
export default PersonaVerificationScreen;