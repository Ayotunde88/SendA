import AddAccountScreen from "../components/src/screens/wallets/AddAccountScreen";

export default AddAccountScreen;
