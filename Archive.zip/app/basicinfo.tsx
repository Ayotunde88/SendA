import BasicInfoScreen from "../components/src/screens/BasicInfoScreen";
export default BasicInfoScreen;
