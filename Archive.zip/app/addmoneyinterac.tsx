import AddMoneyInteracScreen from "../components/src/screens/AddMoney/AddMoneyInteracScreen";
export default AddMoneyInteracScreen;