import CheckEmailScreen from "../components/src/screens/auth/CheckEmailScreen";
export default CheckEmailScreen;
