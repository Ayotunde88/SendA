import TransferConfirmScreen from "../components/src/screens/TransferConfirmScreen";
export default TransferConfirmScreen;