import React from 'react';
import OnboardingCarousel from '../components/OnboardingCarousel';

export default function OnboardingScreen() {
  return <OnboardingCarousel />;
}
