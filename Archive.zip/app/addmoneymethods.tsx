import AddMoneyMethodsScreen from "../components/src/screens/AddMoney/AddMoneyMethodsScreen";
export default AddMoneyMethodsScreen;
