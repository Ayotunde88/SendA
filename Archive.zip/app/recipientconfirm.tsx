import RecipientConfirmScreen from "../components/src/screens/RecipientConfirmScreen";
export default RecipientConfirmScreen;
