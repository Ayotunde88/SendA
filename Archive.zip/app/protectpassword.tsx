import ProtectPasswordScreen from "../components/src/screens/auth/ProtectPasswordScreen";
export default ProtectPasswordScreen;
