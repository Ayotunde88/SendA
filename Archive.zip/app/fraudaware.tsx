import FraudAwareScreen from "../components/src/screens/FraudAwareScreen";
export default FraudAwareScreen;
