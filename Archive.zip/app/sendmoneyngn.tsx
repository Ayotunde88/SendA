import SendMoneyNGNScreen from "../components/src/screens/SendMoneyNGNScreen";
export default SendMoneyNGNScreen;
