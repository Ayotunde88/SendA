import BankDetailScreen from "../components/src/screens/BankDetailScreen";
export default BankDetailScreen;