import ResultScreen from "../components/ResultScreen";

export default ResultScreen;