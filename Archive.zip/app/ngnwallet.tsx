import NgnWalletScreen from "../components/src/screens/NgnWalletScreen";
export default NgnWalletScreen;
