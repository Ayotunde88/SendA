import ProfileScreen from "@/components/src/screens/ProfileScreen";
 export default ProfileScreen; 