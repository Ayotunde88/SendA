import RecipientsScreen from "../components/src/screens/RecipientsScreen";
export default RecipientsScreen;
