import RecipientDetailsScreen from "../components/src/screens/RecipientDetailsScreen";
export default RecipientDetailsScreen;
