import NetworkErrorState from "../components/NetworkErrorState";
export default NetworkErrorState;