import GetStartedScreen from "../components/src/screens/GetStartedScreen";
export default GetStartedScreen;
