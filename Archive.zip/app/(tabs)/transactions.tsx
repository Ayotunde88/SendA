import AllTransactionsScreen from "../../components/src/screens/TransactionsScreen";
export default AllTransactionsScreen;
