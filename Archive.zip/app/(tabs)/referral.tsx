import ReferralScreen from "../../components/src/screens/ReferralScreen";
export default ReferralScreen
