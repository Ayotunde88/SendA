import NotificationScreen from "../../components/src/screens/NotificationScreen";
export default NotificationScreen;