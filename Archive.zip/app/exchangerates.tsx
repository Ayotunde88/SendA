import ExchangeRateScreen from "../components/src/screens/ExchangeRateScreen";
export default ExchangeRateScreen;