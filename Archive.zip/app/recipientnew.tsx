import RecipientNewScreen from "../components/src/screens/RecipientNewScreen";
export default RecipientNewScreen;