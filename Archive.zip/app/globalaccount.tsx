import GlobalAccountScreen from "../components/src/screens/GlobalAccountScreen";
export default GlobalAccountScreen;
