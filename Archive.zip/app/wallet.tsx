import WalletScreen from "../components/src/screens/WalletScreen";
export default WalletScreen;
