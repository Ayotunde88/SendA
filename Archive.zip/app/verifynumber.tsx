import VerifyNumberScreen from "../components/src/screens/VerifyNumberScreen";

export default VerifyNumberScreen;