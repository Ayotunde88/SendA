import SendMoneyScreen from "../components/src/screens/SendMoneyScreen";
export default SendMoneyScreen;
