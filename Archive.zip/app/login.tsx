import LoginScreen from "../components/src/screens/LoginScreen";

export default LoginScreen;
