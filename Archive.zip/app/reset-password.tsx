import ResetPasswordScreen from "../components/src/screens/ResetPasswordScreen";
export default ResetPasswordScreen;
